# Trek Language Specification

## Overview

Trek is a modern coding language designed for declarative programming with a focus on visual elements, styling, and hierarchical structure. It combines data definition, functional programming, and visual layout capabilities.

## File Extension

- `.trek`

## Basic Syntax

### Comments

```trek
// Single-line comment
/* Multi-line
   comment */
```

### Variables and Assignment

```trek
variables {
  is_main = true
  is_functions = false
  count = 42
  name = "example"
}
```

### Data Types

Trek supports the following data types:

- **Boolean**: `true`, `false`
- **Number**: Integer (e.g., `42`) or floating-point (e.g., `3.14`)
- **String**: Quoted text (e.g., `"hello"`, `'world'`)
- **Hexadecimal**: Color notation (e.g., `#ffffff`)
- **Percentage**: Unit notation (e.g., `50%`)
- **Pixels**: Unit notation (e.g., `20px`)

### Sections

Trek programs are organized into numbered sections:

```trek
.file(
  TREK filename: =example.trek=
  1{
    variables { ... }
    content { ... }
  }
)
```

### Styling and Drawing

Trek supports visual element definition:

```trek
.background {
  .color [hex-#ffffff]
}

.draw [ellipse] {
  dimensions {
    radius 20px
  }
  .color [hex-#484848] {
    .color_use = .border; .fill
  }
}
```

### Positioning

Elements can be positioned relative to other objects:

```trek
.pos fromObjCenter(measureAsUnit: percent) {
  -left 50(%)
  -right 50(%)
  -up 90(%)
}
```

### Functions and Objects

```trek
function calculateArea(width, height) {
  return width * height
}

class Shape {
  properties {
    width = 0
    height = 0
  }
}
```

### Operators

Trek supports standard operators:

- **Arithmetic**: `+`, `-`, `*`, `/`, `%`
- **Comparison**: `==`, `!=`, `===`, `!==`, `<`, `>`, `<=`, `>=`
- **Logical**: `&&`, `||`, `!`
- **Conditional**: `?`, `:`

### Control Flow

```trek
if (condition) {
  // do something
} else {
  // do something else
}

for (let i = 0; i < 10; i++) {
  // loop body
}

while (condition) {
  // loop body
}
```

### Imports and Exports

```trek
import { Component } from "module"
export const MyComponent = {...}
```

## Key Built-in Elements

- `.file()` - File definition wrapper
- `.background` - Background styling
- `.color` - Color definition
- `.draw` - Draw element (shapes: ellipse, rectangle, etc.)
- `.border` - Border styling
- `.fill` - Fill styling
- `.pos` - Position definition
- `variables` - Variable block
- `dimensions` - Dimensions block

## Example Program

```trek
.file(
  TREK filename: =demo.trek=
  1{
    variables {
      is_main = true
      bg_color = #f0f0f0
      title = "My Trek App"
    }
    SECTIONSTART[
      .background {
        .color [hex-#ffffff]
      }
      .draw [ellipse] {
        dimensions {
          radius 20px
        }
        .color [hex-#484848] {
          .color_use = .border; .fill
        }
        .pos fromObjCenter(measureAsUnit: percent) {
          -left 50(%)
          -up 90(%)
        }
        object_id [ball]
      }
    ]
  }
)
```

## Reserved Keywords

- `if`, `else`, `for`, `while`, `break`, `continue`
- `function`, `class`, `const`, `let`, `var`
- `return`, `import`, `export`, `from`, `as`
- `true`, `false`, `null`, `undefined`

## Archive Format (.trek.archive)

Trek supports a special archive format that can contain entire directory structures in a single file, making it easy to distribute projects and collections.

### Archive File Extension

- `.trek.archive`

### Archive Structure

Archives use a hierarchical structure to represent files and folders:

```trek
.file(1)(
    TREK filename: =filename.ext=
    (OVERRIDE_ELEMENT--RUNAS)
    (OVERRIDE_ELEMENT--SECTION)
    (OVERRIDE_ELEMENT--VARIABLES)
    --FILECODE{
        // File content goes here
    }
)
.subfolder(1)(
    TREK filename[.ARG is_folder] =folder_name=
    --DIRECTORY{
        // Subfolder contents
    }
)
```

### Archive Elements

#### Files in Archives
- **`.file(index)`** - Represents an individual file
- **`TREK filename: =name.ext=`** - File name and extension
- **`--FILECODE{}`** - Contains the actual file content
- **`(OVERRIDE_ELEMENT--*)`** - Configuration directives

#### Directories in Archives
- **`.subfolder(index)`** - Represents a directory
- **`TREK filename[.ARG is_folder] =name=`** - Directory name with folder flag
- **`--DIRECTORY{}`** - Contains directory contents
- **`[.ARG is_in /path]`** - Path specification for nested files

### Archive Creation

Archives are created automatically when you:
1. Select a folder in your file system
2. Choose "Save As TREK Archive"
3. Trek consolidates all files and subdirectories into one `.trek.archive` file

### Archive Extraction

Archives can be reverted back to their original folder structure for easy access and editing.

### Use Cases

- **Project Distribution** - Share entire projects as single files
- **Template Sharing** - Distribute starter project templates
- **Backup Systems** - Create readable text-based backups
- **Configuration Management** - Share complex configurations

### Example Archive

```trek
.file(1)(
    TREK filename: =index.html=
    (OVERRIDE_ELEMENT--RUNAS)
    (OVERRIDE_ELEMENT--SECTION)
    (OVERRIDE_ELEMENT--VARIABLES)
    --FILECODE{
        <!DOCTYPE html>
        <html>
        <head><title>My App</title></head>
        <body><h1>Hello World!</h1></body>
        </html>
    }
)
.subfolder(1)(
    TREK filename[.ARG is_folder] =assets=
    --DIRECTORY{
        .file[.ARG is_in /assets](1)(
            TREK filename: =style.css=
            (OVERRIDE_ELEMENT--RUNAS)
            (OVERRIDE_ELEMENT--SECTION)
            (OVERRIDE_ELEMENT--VARIABLES)
            --FILECODE{
                body { background: #f0f0f0; }
            }
        )
    }
)
```

## Version History

- **v1.0.0** (2026-03-04) - Initial language specification

---

For more information, visit the Trek project repository.
