# Trek Format Skeleton

This folder contains a minimal skeleton to start defining the Trek coding format.

- File extension: `.trek` (sample: `sample.trek.html`)
- Archive format: `.trek.archive` (sample: `samplearchive.trek.archive`)
- JSON Schema: `trek.schema.json` (minimal AST shape)
- Editor hints: `vscode-language-configuration.json` (simple brackets/comments)
- Package manifest: `package.json` (ready to publish to npm if desired)

How to use:

1. Copy this folder to your Trek format repository root.
2. Edit `trek.schema.json` to reflect the full format structure.
3. Add a VS Code grammar/semantic tokens or an official language server if you want IDE support.
4. Publish to npm so others can `npm install trek-format` or download the archive.

Quick publish (npm):

```bash
cd format-skeleton
npm publish --access public
```

## Archive Tool

Trek includes tools to create `.trek.archive` files from directories:

### Windows
```batch
archive-folder.bat <source_directory> [--recurse] [--replace]
```

### Linux/macOS
```bash
./archive-folder.sh <source_directory> [--recurse] [--replace]
```

### Examples
```bash
# Archive current directory
archive-folder.bat myproject

# Archive recursively (include subdirectories)
archive-folder.bat myproject --recurse

# Replace folder with archive (like ZIP)
archive-folder.bat myproject --replace

# Recursive replace
archive-folder.bat myproject --recurse --replace
```

### Options
- `--recurse`: Include subdirectories in the archive
- `--replace`: Replace the source folder with the archive file (destructive!)

**Archive Naming:** All archives are automatically named `(folder name).trek.archive`
